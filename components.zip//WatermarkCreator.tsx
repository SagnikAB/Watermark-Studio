import { Label } from "./ui/label";
import { Input } from "./ui/input";
import { Slider } from "./ui/slider";
import { Card, CardContent, CardHeader, CardTitle } from "./ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "./ui/tabs";

export interface WatermarkConfig {
  type: 'text' | 'image';
  text: string;
  fontSize: number;
  color: string;
  opacity: number;
  rotation: number;
  spacing: number;
  imageUrl?: string;
  imageSize: number;
}

interface WatermarkCreatorProps {
  config: WatermarkConfig;
  onConfigChange: (config: WatermarkConfig) => void;
}

export function WatermarkCreator({ config, onConfigChange }: WatermarkCreatorProps) {
  const updateConfig = (updates: Partial<WatermarkConfig>) => {
    onConfigChange({ ...config, ...updates });
  };

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (event) => {
        updateConfig({ imageUrl: event.target?.result as string });
      };
      reader.readAsDataURL(file);
    }
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle>Create Watermark</CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <Tabs value={config.type} onValueChange={(value) => updateConfig({ type: value as 'text' | 'image' })}>
          <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="text">Text</TabsTrigger>
            <TabsTrigger value="image">Image</TabsTrigger>
          </TabsList>
          
          <TabsContent value="text" className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="watermark-text">Watermark Text</Label>
              <Input
                id="watermark-text"
                placeholder="Enter watermark text"
                value={config.text}
                onChange={(e) => updateConfig({ text: e.target.value })}
              />
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="font-size">Font Size: {config.fontSize}px</Label>
              <Slider
                id="font-size"
                min={12}
                max={120}
                step={1}
                value={[config.fontSize]}
                onValueChange={([value]) => updateConfig({ fontSize: value })}
              />
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="text-color">Text Color</Label>
              <div className="flex gap-2">
                <Input
                  id="text-color"
                  type="color"
                  value={config.color}
                  onChange={(e) => updateConfig({ color: e.target.value })}
                  className="w-20 h-10"
                />
                <Input
                  value={config.color}
                  onChange={(e) => updateConfig({ color: e.target.value })}
                  placeholder="#000000"
                />
              </div>
            </div>
          </TabsContent>
          
          <TabsContent value="image" className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="watermark-image">Upload Watermark Image</Label>
              <Input
                id="watermark-image"
                type="file"
                accept="image/*"
                onChange={handleImageUpload}
              />
            </div>
            
            {config.imageUrl && (
              <div className="space-y-2">
                <Label>Preview</Label>
                <img src={config.imageUrl} alt="Watermark preview" className="max-h-20 object-contain" />
              </div>
            )}
            
            <div className="space-y-2">
              <Label htmlFor="image-size">Image Size: {config.imageSize}%</Label>
              <Slider
                id="image-size"
                min={5}
                max={100}
                step={5}
                value={[config.imageSize]}
                onValueChange={([value]) => updateConfig({ imageSize: value })}
              />
            </div>
          </TabsContent>
        </Tabs>
        
        <div className="space-y-2">
          <Label htmlFor="opacity">Opacity: {Math.round(config.opacity * 100)}%</Label>
          <Slider
            id="opacity"
            min={0}
            max={100}
            step={1}
            value={[config.opacity * 100]}
            onValueChange={([value]) => updateConfig({ opacity: value / 100 })}
          />
        </div>
        
        <div className="space-y-2">
          <Label htmlFor="rotation">Rotation: {config.rotation}°</Label>
          <Slider
            id="rotation"
            min={-180}
            max={180}
            step={1}
            value={[config.rotation]}
            onValueChange={([value]) => updateConfig({ rotation: value })}
          />
        </div>
        
        <div className="space-y-2">
          <Label htmlFor="spacing">Tile Spacing: {config.spacing}px</Label>
          <Slider
            id="spacing"
            min={100}
            max={500}
            step={10}
            value={[config.spacing]}
            onValueChange={([value]) => updateConfig({ spacing: value })}
          />
          <p className="text-xs text-muted-foreground">
            Distance between repeated watermarks
          </p>
        </div>
      </CardContent>
    </Card>
  );
}
