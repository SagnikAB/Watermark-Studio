import { useEffect, useRef } from 'react';
import { WatermarkConfig } from './WatermarkCreator';

interface ImageCanvasProps {
  image: HTMLImageElement | null;
  watermarkConfig: WatermarkConfig;
  onCanvasReady?: (canvas: HTMLCanvasElement) => void;
}

export function ImageCanvas({ image, watermarkConfig, onCanvasReady }: ImageCanvasProps) {
  const canvasRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    if (!image || !canvasRef.current) return;

    const canvas = canvasRef.current;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    // Set canvas size to match image
    canvas.width = image.width;
    canvas.height = image.height;

    // Draw the original image
    ctx.drawImage(image, 0, 0);

    // Apply tiled watermark
    if (watermarkConfig.type === 'text' && watermarkConfig.text) {
      applyTiledTextWatermark(ctx, canvas, watermarkConfig);
      if (onCanvasReady) onCanvasReady(canvas);
    } else if (watermarkConfig.type === 'image' && watermarkConfig.imageUrl) {
      const watermarkImg = new Image();
      watermarkImg.onload = () => {
        applyTiledImageWatermark(ctx, canvas, watermarkConfig, watermarkImg);
        if (onCanvasReady) onCanvasReady(canvas);
      };
      watermarkImg.src = watermarkConfig.imageUrl;
    } else {
      if (onCanvasReady) onCanvasReady(canvas);
    }
  }, [image, watermarkConfig, onCanvasReady]);

  return (
    <div className="flex items-center justify-center bg-muted/30 rounded-lg p-4 min-h-[400px]">
      {image ? (
        <canvas
          ref={canvasRef}
          className="max-w-full max-h-[600px] object-contain shadow-lg"
        />
      ) : (
        <div className="text-muted-foreground">No image loaded</div>
      )}
    </div>
  );
}

function applyTiledTextWatermark(
  ctx: CanvasRenderingContext2D,
  canvas: HTMLCanvasElement,
  config: WatermarkConfig
) {
  ctx.save();
  ctx.globalAlpha = config.opacity;
  ctx.font = `${config.fontSize}px Arial`;
  ctx.fillStyle = config.color;
  ctx.textAlign = 'center';
  ctx.textBaseline = 'middle';

  // Measure text to calculate proper spacing
  const textMetrics = ctx.measureText(config.text);
  const textWidth = textMetrics.width;
  const textHeight = config.fontSize;

  // Calculate spacing with padding
  const spacing = config.spacing;
  const diagonalSpacing = Math.sqrt(spacing * spacing * 2);

  // Calculate how many tiles we need (with extra buffer for rotation)
  const maxDimension = Math.max(canvas.width, canvas.height);
  const tilesNeeded = Math.ceil(maxDimension * 2 / spacing) + 2;

  // Draw watermarks in a grid pattern
  for (let row = -tilesNeeded; row < tilesNeeded; row++) {
    for (let col = -tilesNeeded; col < tilesNeeded; col++) {
      const x = col * spacing + (row % 2) * (spacing / 2);
      const y = row * diagonalSpacing;

      ctx.save();
      ctx.translate(x, y);
      ctx.rotate((config.rotation * Math.PI) / 180);
      ctx.fillText(config.text, 0, 0);
      ctx.restore();
    }
  }

  ctx.restore();
}

function applyTiledImageWatermark(
  ctx: CanvasRenderingContext2D,
  canvas: HTMLCanvasElement,
  config: WatermarkConfig,
  watermarkImg: HTMLImageElement
) {
  ctx.save();
  ctx.globalAlpha = config.opacity;

  const scale = config.imageSize / 100;
  const imgWidth = watermarkImg.width * scale;
  const imgHeight = watermarkImg.height * scale;

  // Calculate spacing
  const spacing = config.spacing;
  const diagonalSpacing = Math.sqrt(spacing * spacing * 2);

  // Calculate how many tiles we need
  const maxDimension = Math.max(canvas.width, canvas.height);
  const tilesNeeded = Math.ceil(maxDimension * 2 / spacing) + 2;

  // Draw watermark images in a grid pattern
  for (let row = -tilesNeeded; row < tilesNeeded; row++) {
    for (let col = -tilesNeeded; col < tilesNeeded; col++) {
      const x = col * spacing + (row % 2) * (spacing / 2);
      const y = row * diagonalSpacing;

      ctx.save();
      ctx.translate(x, y);
      ctx.rotate((config.rotation * Math.PI) / 180);
      ctx.drawImage(watermarkImg, -imgWidth / 2, -imgHeight / 2, imgWidth, imgHeight);
      ctx.restore();
    }
  }

  ctx.restore();
}
